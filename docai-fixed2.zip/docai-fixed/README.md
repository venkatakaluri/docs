# Document Formatter — Free Online (Groq AI)

Paste raw text → AI formats it → download Word file.
Free forever. Works online. Works on mobile.

---

## STEP 1 — Get Free Groq API Key (2 minutes)

1. Go to https://console.groq.com
2. Sign up (free, no credit card needed)
3. Click "API Keys" → "Create API Key"
4. Copy the key (starts with gsk_...)
5. Open server.js and replace:
   YOUR_GROQ_API_KEY_HERE
   with your actual key

---

## STEP 2 — Run Locally (test it first)

Install Node.js from https://nodejs.org if not already installed.

Open terminal in this folder:
```
npm install
node server.js
```
Open http://localhost:3000 — paste text, download Word file.

---

## STEP 3 — Put it Online FREE (Render.com)

This makes it work on any device, any browser, anywhere in the world.

1. Create free account at https://render.com

2. Push your code to GitHub:
   - Create account at https://github.com
   - Create new repository
   - Upload all files from this folder (except node_modules)

3. On Render:
   - Click "New" → "Web Service"
   - Connect your GitHub account
   - Select your repository
   - Settings:
       Name: document-formatter (or anything)
       Runtime: Node
       Build Command: npm install
       Start Command: node server.js
   - Click "Create Web Service"

4. Add your Groq API key as environment variable on Render:
   - Go to your service → "Environment"
   - Add: GROQ_API_KEY = your_key_here

5. Update server.js to read from environment:
   Change this line:
   const GROQ_API_KEY = 'YOUR_GROQ_API_KEY_HERE';
   To this:
   const GROQ_API_KEY = process.env.GROQ_API_KEY || 'YOUR_GROQ_API_KEY_HERE';

6. Render gives you a free URL like:
   https://document-formatter.onrender.com
   Share this with anyone — works on phone, tablet, any browser.

---

## GROQ FREE TIER LIMITS

- 14,400 requests per day
- That means 14,400 documents per day — more than enough
- No credit card needed
- Never expires

---

## HOW TO USE

Just paste anything into the box:

EXAMPLE 1 — Question paper:
Q1 what is photosynthesis 2 marks
Q2 name the organelle 1 mark
→ Gets proper sections, marks right-aligned, answer lines

EXAMPLE 2 — Notes:
French Revolution causes financial crisis food shortage
key events storming of bastille 1789
→ Gets headings, bullet points, proper structure

EXAMPLE 3 — Anything else:
Project report, resume, meeting notes, lab report
→ AI detects what it is and formats accordingly
